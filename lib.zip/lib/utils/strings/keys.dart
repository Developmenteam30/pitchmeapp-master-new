class Keys {
  static String TOKEN = "TOKEN";
  static String USER_TYPE = "USER_TYPE";

  //dev
  static const googleApiKey = 'AIzaSyArVg2eeb6UbZtIgSHLEqUpHD1Itj5nYsw';
}
